'use client';

import type { GrafcetDiagram } from '@/lib/types';
import GrafcetStep from './grafcet-step';
import GrafcetTransition from './grafcet-transition';
import GrafcetReference from './grafcet-reference';
import GrafcetLink from './grafcet-link';
import type { SelectedElement } from '@/app/page';

interface GrafcetCanvasProps {
  diagram: GrafcetDiagram;
  activeSteps: string[];
  linkingState: { fromId: string; fromType: string } | null;
  selectedElements: SelectedElement[];
  onDragStart: (e: React.DragEvent, id: string, type: 'step' | 'transition' | 'reference') => void;
  onDeleteElement: (id: string, type: 'step' | 'transition' | 'reference') => void;
  onConnectorClick: (e: React.MouseEvent, id: string, type: 'step' | 'transition' | 'reference') => void;
  onElementClick: (e: React.MouseEvent, id: string, type: 'step' | 'transition' | 'reference') => void;
}

export default function GrafcetCanvas({ 
  diagram, 
  activeSteps, 
  linkingState,
  selectedElements,
  onDragStart, 
  onDeleteElement,
  onConnectorClick,
  onElementClick
}: GrafcetCanvasProps) {
  const { steps, transitions, references } = diagram;

  const isSelected = (id: string) => selectedElements.some(el => el.id === id);

  return (
    <div className="w-full h-full relative" style={{ minWidth: '2000px', minHeight: '1500px' }}>
      {[...steps, ...references].flatMap(step =>
        step.connectedTo.map(transitionId => (
          <GrafcetLink
            key={`${step.id}-${transitionId}`}
            diagram={diagram}
            fromId={step.id}
            toId={transitionId}
            type="step-to-transition"
          />
        ))
      )}
      {transitions.flatMap(transition =>
        transition.connectedTo.map(stepId => (
          <GrafcetLink
            key={`${transition.id}-${stepId}`}
            diagram={diagram}
            fromId={transition.id}
            toId={stepId}
            type="transition-to-step"
          />
        ))
      )}
      {steps.map(step => (
        <GrafcetStep 
          key={step.id} 
          step={step} 
          isActive={activeSteps.includes(step.id)}
          isSelected={isSelected(step.id)}
          isLinkingFrom={linkingState?.fromId === step.id}
          onDragStart={(e, stepId) => onDragStart(e, stepId, 'step')}
          onDelete={(id) => onDeleteElement(id, 'step')}
          onConnectorClick={(e, id) => onConnectorClick(e, id, 'step')}
          onClick={(e, id) => onElementClick(e, id, 'step')}
        />
      ))}
      {transitions.map(transition => (
        <GrafcetTransition 
          key={transition.id} 
          transition={transition}
          isSelected={isSelected(transition.id)}
          isLinkingFrom={linkingState?.fromId === transition.id}
          onDragStart={(e, transitionId) => onDragStart(e, transitionId, 'transition')}
          onDelete={(id) => onDeleteElement(id, 'transition')}
          onConnectorClick={(e, id) => onConnectorClick(e, id, 'transition')}
          onClick={(e, id) => onElementClick(e, id, 'transition')}
        />
      ))}
      {references && references.map(reference => (
        <GrafcetReference 
          key={reference.id} 
          reference={reference}
          isSelected={isSelected(reference.id)}
          isLinkingFrom={linkingState?.fromId === reference.id}
          onDragStart={(e, refId) => onDragStart(e, refId, 'reference')}
          onDelete={(id) => onDeleteElement(id, 'reference')}
          onConnectorClick={(e, id) => onConnectorClick(e, id, 'reference')}
          onClick={(e, id) => onElementClick(e, id, 'reference')}
        />
      ))}
    </div>
  );
}
