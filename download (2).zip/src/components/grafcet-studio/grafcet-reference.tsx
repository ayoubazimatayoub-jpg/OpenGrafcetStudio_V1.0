
'use client';

import { cn } from '@/lib/utils';
import type { GrafcetReference as GrafcetReferenceType } from '@/lib/types';
import { Button } from '../ui/button';
import { X, Link2, ArrowUp, ArrowDown } from 'lucide-react';
import { ReferenceInIcon, ReferenceOutIcon } from '../icons/grafcet-icons';

interface GrafcetReferenceProps {
  reference: GrafcetReferenceType;
  isSelected: boolean;
  isLinkingFrom: boolean;
  onDragStart: (e: React.DragEvent, refId: string) => void;
  onDelete: (id: string) => void;
  onConnectorClick: (e: React.MouseEvent, id: string) => void;
  onClick: (e: React.MouseEvent, id: string) => void;
}

const REF_WIDTH = 50;
const REF_HEIGHT = 25;

export default function GrafcetReference({ reference, isSelected, isLinkingFrom, onDragStart, onDelete, onConnectorClick, onClick }: GrafcetReferenceProps) {
  const isOut = reference.type === 'REFERENCE_OUT';
  
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, reference.id)}
      onClick={(e) => onClick(e, reference.id)}
      className="absolute flex flex-col items-center justify-center group cursor-grab active:cursor-grabbing"
      style={{
        left: reference.position.x,
        top: reference.position.y,
        width: REF_WIDTH,
      }}
    >
        {isOut ? null : (
            <p className="text-sm font-semibold mb-1">{reference.targetLabel}</p>
        )}
        <div
            className={cn(
                "relative text-foreground",
                isSelected && "text-primary",
                isLinkingFrom && "text-blue-500",
            )}
            style={{ width: REF_WIDTH, height: REF_HEIGHT }}
        >
            {isOut ? <ReferenceOutIcon className="w-full h-full" /> : <ReferenceInIcon className="w-full h-full" />}
        </div>
         {isOut ? (
            <p className="text-sm font-semibold mt-1">{reference.targetLabel}</p>
        ) : null}

        <Button
          variant="destructive"
          size="icon"
          className="absolute -top-3 -right-3 h-6 w-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-20"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(reference.id);
          }}
        >
          <X className="h-4 w-4" />
        </Button>
        <div 
            className={cn(
                "absolute left-1/2 -translate-x-1/2 h-6 w-6 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20",
                isOut ? "-top-3" : "-bottom-3"
            )}
            onClick={(e) => onConnectorClick(e, reference.id)}
        >
            <Button
                variant="outline"
                size="icon"
                className="h-6 w-6 rounded-full bg-background hover:bg-accent"
            >
                <Link2 className="h-4 w-4" />
            </Button>
        </div>
    </div>
  );
}
