import type { GrafcetDiagram, GrafcetStep, GrafcetTransition, GrafcetReference } from '@/lib/types';

interface GrafcetLinkProps {
  diagram: GrafcetDiagram;
  fromId: string;
  toId: string;
  type: 'step-to-transition' | 'transition-to-step';
}

const STEP_SIZE = 60;
const TRANSITION_WIDTH = 60;
const TRANSITION_HEIGHT = 12;
const LOOP_OFFSET = 80;

// Helper function to get connection points
const getAttachmentPoint = (
    element: GrafcetStep | GrafcetTransition | GrafcetReference,
    direction: 'top' | 'bottom' | 'left' | 'right',
    connectedElementId: string,
    allConnections: string[]
) => {
    const isStep = 'actions' in element;
    const isReference = 'targetLabel' in element;

    let elementWidth, elementHeight;
    let isAndElement = false;

    if (isStep) {
        isAndElement = (element as GrafcetStep).type.startsWith('AND');
        elementWidth = isAndElement ? (element as GrafcetStep).width || STEP_SIZE : STEP_SIZE;
        elementHeight = isAndElement ? 12 : STEP_SIZE;
    } else if(isReference) {
        elementWidth = 50;
        elementHeight = 25;
    } else { // Transition
        elementWidth = TRANSITION_WIDTH;
        elementHeight = TRANSITION_HEIGHT;
    }


    // If it's not an AND element, always connect to the center.
    if (!isAndElement) {
        if (direction === 'top') return { x: element.position.x + elementWidth / 2, y: element.position.y };
        if (direction === 'bottom') return { x: element.position.x + elementWidth / 2, y: element.position.y + elementHeight };
        if (direction === 'left') return { x: element.position.x, y: element.position.y + elementHeight / 2 };
        if (direction === 'right') return { x: element.position.x + elementWidth, y: element.position.y + elementHeight / 2 };
    }

    // For AND elements, distribute the connection points.
    const totalConnections = allConnections.length;
    const connectionIndex = allConnections.findIndex(id => id === connectedElementId);
    
    // Distribute points along the edge for multiple connections on AND elements
    const spacing = elementWidth / (totalConnections + 1);
    const pointX = element.position.x + spacing * (connectionIndex + 1);

    if (direction === 'top') return { x: pointX, y: element.position.y };
    if (direction === 'bottom') return { x: pointX, y: element.position.y + elementHeight };
    
    // Default fallback for left/right on AND elements
    return { x: element.position.x + elementWidth / 2, y: element.position.y };
};


export default function GrafcetLink({ diagram, fromId, toId, type }: GrafcetLinkProps) {
  const fromEl = diagram.steps.find(s => s.id === fromId) || diagram.transitions.find(t => t.id === fromId) || diagram.references.find(r => r.id === fromId);
  const toEl = diagram.steps.find(s => s.id === toId) || diagram.transitions.find(t => t.id === toId) || diagram.references.find(r => r.id === toId);

  if (!fromEl || !toEl) return null;
  
  // No links to/from an IN reference, they are entry points
  if (('type' in fromEl && fromEl.type === 'REFERENCE_IN') || ('type' in toEl && toEl.type === 'REFERENCE_IN')) {
    return null;
  }
  
  const isFeedbackLoop = fromEl.position.y > toEl.position.y;
  
  let p1, p2;

  if (type === 'step-to-transition') { // Includes Ref-Out to Transition
      p1 = getAttachmentPoint(fromEl, 'bottom', toId, fromEl.connectedTo);
      // For the 'to' element (a transition), we find all steps that connect to it
      const predecessorSteps = [...diagram.steps, ...diagram.references].filter(s => s.connectedTo.includes(toId)).map(s => s.id);
      p2 = getAttachmentPoint(toEl, 'top', fromId, predecessorSteps);
  } else { // transition-to-step, includes transition-to-ref-out
      p1 = getAttachmentPoint(fromEl, 'bottom', toId, fromEl.connectedTo);
      // For the 'to' element (a step or ref), we find all transitions that connect to it
      const predecessorTransitions = diagram.transitions.filter(t => t.connectedTo.includes(toId)).map(t => t.id);
      p2 = getAttachmentPoint(toEl, 'top', fromId, predecessorTransitions);
  }

  let { x: x1, y: y1 } = p1;
  let { x: x2, y: y2 } = p2;
  
  let pathData;

  if (isFeedbackLoop && type === 'transition-to-step') {
      const midX = Math.min(x1, x2) - LOOP_OFFSET;
      
      pathData = `M ${x1} ${y1} V ${y1 + LOOP_OFFSET / 2} H ${midX} V ${y2 - LOOP_OFFSET / 2} H ${x2} V ${y2}`;
  } else {
    if (Math.abs(x1 - x2) < 1) { // Almost vertical line
      pathData = `M ${x1} ${y1} V ${y2}`;
    } else {
      const midY = y1 + (y2 - y1) / 2;
      pathData = `M ${x1} ${y1} V ${midY} H ${x2} V ${y2}`;
    }
  }


  return (
    <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" style={{ overflow: 'visible' }}>
      <defs>
        <marker
          id="arrowhead"
          viewBox="0 0 10 10"
          refX="5"
          refY="5"
          markerWidth="6"
          markerHeight="6"
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" className="fill-current text-foreground" />
        </marker>
      </defs>
      <path
        d={pathData}
        className="stroke-current text-foreground"
        strokeWidth="1.5"
        fill="none"
        markerEnd="url(#arrowhead)"
      />
    </svg>
  );
}
