'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import type { GrafcetVariable, GrafcetDiagram, ProjectInfo } from '@/lib/types';
import { AndConvergenceIcon, AndDivergenceIcon, InitialStepIcon, StepIcon, TransitionIcon, ReferenceInIcon, ReferenceOutIcon } from '../icons/grafcet-icons';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Trash2, Pencil, PlusCircle } from 'lucide-react';
import { useForm, Controller, useForm as useFormProject } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';

interface LeftPanelProps {
  diagram: GrafcetDiagram;
  setDiagram: (diagram: GrafcetDiagram, overwriteHistory?: boolean) => void;
  onDragStart: (e: React.DragEvent, symbolType: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const symbols = [
  { name: 'Initial Step', type: 'STEP_INITIAL', icon: <InitialStepIcon /> },
  { name: 'Step', type: 'STEP_NORMAL', icon: <StepIcon /> },
  { name: 'Transition', type: 'TRANSITION', icon: <TransitionIcon /> },
  { name: 'Divergence', type: 'AND_DIVERGENCE', icon: <AndDivergenceIcon /> },
  { name: 'Convergence', type: 'AND_CONVERGENCE', icon: <AndConvergenceIcon /> },
  { name: 'Input Ref', type: 'REFERENCE_IN', icon: <ReferenceInIcon /> },
  { name: 'Output Ref', type: 'REFERENCE_OUT', icon: <ReferenceOutIcon /> },
];

const variableSchema = z.object({
  name: z.string().min(1, 'Name is required').regex(/^[a-zA-Z0-9_]+$/, 'Only letters, numbers, and underscores'),
  type: z.enum(['I', 'Q', 'T', 'C', 'Internal']),
  alias: z.string().optional(),
});

const projectInfoSchema = z.object({
    title: z.string().min(1, 'Title is required'),
    author: z.string().min(1, 'Author is required'),
    version: z.string().min(1, 'Version is required'),
    description: z.string().optional(),
});

type VariableFormData = z.infer<typeof variableSchema>;
type ProjectInfoFormData = z.infer<typeof projectInfoSchema>;


const ProjectInfoPanel = ({ diagram, setDiagram }: { diagram: GrafcetDiagram; setDiagram: (diagram: GrafcetDiagram, overwriteHistory?: boolean) => void; }) => {
    const { register, handleSubmit, watch, reset, formState: { errors } } = useFormProject<ProjectInfoFormData>({
        resolver: zodResolver(projectInfoSchema),
        defaultValues: diagram.projectInfo,
    });

    useEffect(() => {
        reset(diagram.projectInfo);
    }, [diagram.projectInfo, reset]);

    useEffect(() => {
        const subscription = watch((value) => {
            const newDiagram = JSON.parse(JSON.stringify(diagram));
            newDiagram.projectInfo = value as ProjectInfo;
            setDiagram(newDiagram, true);
        });
        return () => subscription.unsubscribe();
    }, [watch, diagram, setDiagram]);

    return (
        <form className="p-4 space-y-4">
            <div className='space-y-2'>
                <Label htmlFor='title'>Project Title</Label>
                <Input id='title' {...register('title')} />
                {errors.title && <p className="text-xs text-destructive mt-1">{errors.title.message}</p>}
            </div>
            <div className='space-y-2'>
                <Label htmlFor='author'>Author</Label>
                <Input id='author' {...register('author')} />
                {errors.author && <p className="text-xs text-destructive mt-1">{errors.author.message}</p>}
            </div>
            <div className='space-y-2'>
                <Label htmlFor='version'>Version</Label>
                <Input id='version' {...register('version')} />
                {errors.version && <p className="text-xs text-destructive mt-1">{errors.version.message}</p>}
            </div>
            <div className='space-y-2'>
                <Label htmlFor='description'>Description</Label>
                <Textarea id='description' {...register('description')} />
            </div>
        </form>
    );
};

export default function LeftPanel({ diagram, setDiagram, onDragStart }: LeftPanelProps) {
  const [editingVariable, setEditingVariable] = useState<GrafcetVariable | null>(null);

  const { register, handleSubmit, control, reset, setValue, formState: { errors } } = useForm<VariableFormData>({
    resolver: zodResolver(variableSchema),
  });

  const handleAddOrUpdateVariable = (data: VariableFormData) => {
    const newDiagram = JSON.parse(JSON.stringify(diagram));
    const newVariable: GrafcetVariable = { ...data, value: data.type === 'I' || data.type === 'Q' ? false : undefined };
    
    if (editingVariable) {
      const index = newDiagram.variables.findIndex((v: GrafcetVariable) => v.name === editingVariable.name);
      if (index !== -1) {
        newDiagram.variables[index] = newVariable;
      }
    } else {
      if (newDiagram.variables.some((v: GrafcetVariable) => v.name === newVariable.name)) {
        // TODO: Show error to user
        console.error("Variable name already exists");
        return;
      }
      newDiagram.variables.push(newVariable);
    }
    
    setDiagram(newDiagram);
    setEditingVariable(null);
    reset({ name: '', type: 'I', alias: ''});
  };

  const handleDeleteVariable = (name: string) => {
    const newDiagram = JSON.parse(JSON.stringify(diagram));
    newDiagram.variables = newDiagram.variables.filter((v: GrafcetVariable) => v.name !== name);
    setDiagram(newDiagram);
  };

  const handleEditVariable = (variable: GrafcetVariable) => {
    setEditingVariable(variable);
    setValue('name', variable.name);
    setValue('type', variable.type);
    setValue('alias', variable.alias || '');
  };

  return (
    <Card className="h-full w-80 border-r border-t-0 rounded-none shadow-md">
      <Tabs defaultValue="symbols" className="flex flex-col h-full">
        <TabsList className="grid w-full grid-cols-3 rounded-none">
          <TabsTrigger value="symbols">Symbols</TabsTrigger>
          <TabsTrigger value="variables">Variables</TabsTrigger>
          <TabsTrigger value="project">Project</TabsTrigger>
        </TabsList>
        <TabsContent value="symbols" className="flex-1 overflow-hidden p-0">
          <ScrollArea className="h-full">
            <div className="p-4 grid grid-cols-2 gap-4">
              {symbols.map(symbol => (
                <div 
                  key={symbol.name} 
                  draggable
                  onDragStart={(e) => onDragStart(e, symbol.type)}
                  className="flex flex-col items-center justify-center gap-2 rounded-lg border p-4 aspect-square bg-card hover:bg-accent/20 cursor-grab active:cursor-grabbing transition-colors"
                >
                  <div className="w-8 h-8 flex items-center justify-center text-primary">{symbol.icon}</div>
                  <span className="text-xs text-center text-muted-foreground">{symbol.name}</span>
                </div>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>
        <TabsContent value="variables" className="flex-1 overflow-hidden p-0 m-0">
           <div className="flex flex-col h-full">
            <form onSubmit={handleSubmit(handleAddOrUpdateVariable)} className="p-4 space-y-4 border-b">
              <h3 className="font-semibold text-foreground">{editingVariable ? 'Edit Variable' : 'Add Variable'}</h3>
              <div>
                <Input placeholder="Name (e.g., Sensor_A)" {...register('name')} disabled={!!editingVariable}/>
                {errors.name && <p className="text-xs text-destructive mt-1">{errors.name.message}</p>}
              </div>
              <div>
                <Input placeholder="Alias (e.g., Start Button)" {...register('alias')} />
              </div>
              <div>
                <Controller
                    control={control}
                    name="type"
                    defaultValue="I"
                    render={({ field }) => (
                    <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                        <SelectItem value="I">Input (I)</SelectItem>
                        <SelectItem value="Q">Output (Q)</SelectItem>
                        <SelectItem value="T">Timer (T)</SelectItem>
                        <SelectItem value="C">Counter (C)</SelectItem>
                        <SelectItem value="Internal">Internal</SelectItem>
                        </SelectContent>
                    </Select>
                    )}
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  {editingVariable ? 'Update' : 'Add'}
                </Button>
                {editingVariable && (
                  <Button variant="outline" onClick={() => { setEditingVariable(null); reset({ name: '', type: 'I', alias: ''}); }}>Cancel</Button>
                )}
              </div>
            </form>
            <ScrollArea className="flex-1">
                <div className="space-y-2 p-4">
                {diagram.variables.map(variable => (
                    <div key={variable.name} className="flex items-center justify-between rounded-md border p-3">
                    <div>
                        <p className="font-mono text-sm font-semibold">{variable.name}</p>
                        {variable.alias && <p className="text-xs text-muted-foreground">{variable.alias}</p>}
                    </div>
                    <div className="flex items-center gap-2">
                        <Badge variant={variable.type === 'I' || variable.type === 'Q' ? 'secondary' : 'outline'}>
                            {variable.type}
                        </Badge>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEditVariable(variable)}>
                            <Pencil className="h-4 w-4"/>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => handleDeleteVariable(variable.name)}>
                            <Trash2 className="h-4 w-4"/>
                        </Button>
                    </div>
                    </div>
                ))}
                </div>
            </ScrollArea>
           </div>
        </TabsContent>
        <TabsContent value="project" className="flex-1 overflow-auto p-0 m-0">
          <ProjectInfoPanel diagram={diagram} setDiagram={setDiagram} />
        </TabsContent>
      </Tabs>
    </Card>
  );
}
