'use client';

import { cn } from '@/lib/utils';
import type { GrafcetStep as GrafcetStepType } from '@/lib/types';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '../ui/button';
import { X, Link2 } from 'lucide-react';

interface GrafcetStepProps {
  step: GrafcetStepType;
  isActive: boolean;
  isSelected: boolean;
  isLinkingFrom: boolean;
  onDragStart: (e: React.DragEvent, stepId: string) => void;
  onDelete: (id: string) => void;
  onConnectorClick: (e: React.MouseEvent, id: string) => void;
  onClick: (e: React.MouseEvent, id: string) => void;
}

const STEP_SIZE = 60;
const INITIAL_STEP_INSET = 6;
const DIVERGENCE_CONVERGENCE_HEIGHT = 12;

export default function GrafcetStep({ step, isActive, isSelected, isLinkingFrom, onDragStart, onDelete, onConnectorClick, onClick }: GrafcetStepProps) {
  const isInitial = step.type === 'STEP_INITIAL';
  const isAndDivergence = step.type === 'AND_DIVERGENCE';
  const isAndConvergence = step.type === 'AND_CONVERGENCE';

  if (isAndDivergence || isAndConvergence) {
    return (
      <div
        draggable
        onDragStart={(e) => onDragStart(e, step.id)}
        onClick={(e) => onClick(e, step.id)}
        className="absolute flex items-center justify-center group cursor-grab active:cursor-grabbing"
        style={{
          left: step.position.x,
          top: step.position.y,
          width: step.width || STEP_SIZE,
          height: DIVERGENCE_CONVERGENCE_HEIGHT,
        }}
      >
        <div
          className={cn(
            "relative w-full h-full flex flex-col justify-between p-1",
            isSelected && "bg-primary/20"
          )}
        >
          <div className={cn("h-0.5 w-full", isSelected ? "bg-primary" : "bg-foreground")}></div>
          <div className={cn("h-0.5 w-full", isSelected ? "bg-primary" : "bg-foreground")}></div>
        </div>
        <Button
          variant="destructive"
          size="icon"
          className="absolute -top-3 -right-3 h-6 w-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-20"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(step.id);
          }}
        >
          <X className="h-4 w-4" />
        </Button>
         <div 
            className="absolute -bottom-3 left-1/2 -translate-x-1/2 h-6 w-6 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20"
            onClick={(e) => onConnectorClick(e, step.id)}
            >
            <Button
                variant="outline"
                size="icon"
                className="h-6 w-6 rounded-full bg-background hover:bg-accent"
            >
                <Link2 className="h-4 w-4" />
            </Button>
         </div>
      </div>
    );
  }
  
  const actionsText = step.actions.filter(a => a.variable).map(a => a.variable).join(', ');

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            draggable
            onDragStart={(e) => onDragStart(e, step.id)}
            onClick={(e) => onClick(e, step.id)}
            className="absolute flex items-start justify-center group"
            style={{
              left: step.position.x,
              top: step.position.y,
            }}
          >
            <div
              className={cn(
                "relative flex items-center justify-center bg-card border-2 font-bold text-lg transition-all duration-300 cursor-grab active:cursor-grabbing",
                isActive && "border-accent shadow-lg shadow-accent/50",
                isLinkingFrom && "border-blue-500 shadow-lg shadow-blue-500/50",
                isSelected && "border-primary shadow-lg shadow-primary/50"
              )}
              style={{
                width: STEP_SIZE,
                height: STEP_SIZE,
              }}
            >
              {isInitial && (
                <div
                  className={cn(
                    "absolute border-2",
                     isActive && "border-accent",
                     isLinkingFrom && "border-blue-500",
                     isSelected && "border-primary"
                  )}
                  style={{
                    top: INITIAL_STEP_INSET,
                    left: INITIAL_STEP_INSET,
                    right: INITIAL_STEP_INSET,
                    bottom: INITIAL_STEP_INSET,
                  }}
                />
              )}
              {isActive && (
                   <div className="absolute h-3 w-3 rounded-full bg-accent animate-ping" />
              )}
              <span className="z-10">{step.label}</span>
              <Button
                variant="destructive"
                size="icon"
                className="absolute -top-3 -right-3 h-6 w-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-20"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(step.id);
                }}
              >
                <X className="h-4 w-4" />
              </Button>
              <div 
                className="absolute -bottom-3 left-1/2 -translate-x-1/2 h-6 w-6 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20"
                onClick={(e) => onConnectorClick(e, step.id)}
              >
                <Button
                    variant="outline"
                    size="icon"
                    className="h-6 w-6 rounded-full bg-background hover:bg-accent"
                >
                    <Link2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            {actionsText && (
                <div className="pl-2 pt-1 font-mono text-xs w-48 whitespace-pre-wrap">
                    {actionsText}
                </div>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent>
            <p className="font-semibold">Step {step.label}</p>
            {step.actions.length > 0 && (
                <div className="mt-2">
                    {step.actions.map((action, i) => (
                        <p key={i} className="text-sm font-mono">{action.variable} := {action.logic}</p>
                    ))}
                </div>
            )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
