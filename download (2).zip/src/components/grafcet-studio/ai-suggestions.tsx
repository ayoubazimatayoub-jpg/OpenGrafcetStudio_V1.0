'use client';

import { useState } from 'react';
import { Bot, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { getGrafcetSuggestions } from '@/ai/flows/ai-powered-suggestions';
import type { GrafcetDiagram } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '../ui/scroll-area';

interface AISuggestionsProps {
  diagram: GrafcetDiagram;
}

export default function AISuggestions({ diagram }: AISuggestionsProps) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleGetSuggestions = async () => {
    setIsLoading(true);
    setError(null);
    setSuggestions([]);
    try {
      const result = await getGrafcetSuggestions({
        grafcetDiagram: JSON.stringify(diagram),
      });
      setSuggestions(result.suggestions);
    } catch (e) {
      console.error(e);
      setError('Failed to get suggestions. Please try again.');
      toast({
        variant: "destructive",
        title: "AI Suggestion Error",
        description: "There was a problem contacting the AI service.",
      })
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 h-full">
      <div className="space-y-2">
        <h3 className="font-semibold text-foreground">AI Powered Suggestions</h3>
        <p className="text-sm text-muted-foreground">
          Use generative AI to analyze your diagram for potential issues, improvements, and alternative designs.
        </p>
      </div>
      <Button onClick={handleGetSuggestions} disabled={isLoading}>
        {isLoading ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <Bot className="mr-2 h-4 w-4" />
        )}
        Analyze Diagram
      </Button>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {suggestions.length > 0 && (
        <div className="mt-4 flex-1 overflow-hidden">
            <h4 className="font-semibold mb-2">Suggestions</h4>
            <ScrollArea className="h-full pr-4">
                <ul className="list-disc space-y-2 pl-5 text-sm text-muted-foreground">
                {suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                ))}
                </ul>
            </ScrollArea>
        </div>
      )}
    </div>
  );
}
