'use client';

import {
  AlignHorizontalJustifyCenter,
  AlignHorizontalJustifyEnd,
  AlignHorizontalJustifyStart,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd,
  AlignVerticalJustifyStart,
  Bot,
  Download,
  Pause,
  Play,
  Trash2,
  Undo,
  Redo,
  BoxSelect,
  Columns3,
  Rows3,
  FileImage,
  Upload,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ThemeToggle } from '@/components/grafcet-studio/theme-toggle';
import { Separator } from '../ui/separator';

interface StudioHeaderProps {
  onImport: () => void;
  onExport: () => void;
  onExportSvg: () => void;
  isSimulating: boolean;
  onToggleSimulation: () => void;
  onClear: () => void;
  selectedElementCount: number;
  onAlign: (alignment: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onSelectAll: () => void;
}

export default function StudioHeader({ onImport, onExport, onExportSvg, isSimulating, onToggleSimulation, onClear, selectedElementCount, onAlign, onUndo, onRedo, canUndo, canRedo, onSelectAll }: StudioHeaderProps) {
  return (
    <header className="flex h-16 items-center justify-between border-b bg-card px-4 md:px-6 shrink-0">
      <div className="flex items-center gap-4">
        <Bot className="h-8 w-8 text-primary" />
        <h1 className="text-xl font-bold tracking-tighter">GRAFCET Studio</h1>
      </div>
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onUndo} disabled={!canUndo}><Undo className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onRedo} disabled={!canRedo}><Redo className="h-4 w-4" /></Button>
        </div>
        <Separator orientation="vertical" className="h-8" />
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onSelectAll} title="Select All (Ctrl+A)">
          <BoxSelect className="h-4 w-4" />
        </Button>
        {selectedElementCount > 1 && (
            <>
                <Separator orientation="vertical" className="h-8" />
                <div className="flex items-center gap-1 rounded-md border bg-background p-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('left')}><AlignHorizontalJustifyStart className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('center-v')}><AlignHorizontalJustifyCenter className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('right')}><AlignHorizontalJustifyEnd className="h-4 w-4" /></Button>
                    <Separator orientation="vertical" className="h-6 mx-1" />
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('top')}><AlignVerticalJustifyStart className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('center-h')}><AlignVerticalJustifyCenter className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('bottom')}><AlignVerticalJustifyEnd className="h-4 w-4" /></Button>
                    <Separator orientation="vertical" className="h-6 mx-1" />
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('distribute-h')}><Rows3 className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onAlign('distribute-v')}><Columns3 className="h-4 w-4" /></Button>
                </div>
            </>
        )}
        <Separator orientation="vertical" className="h-8" />
        <Button variant="outline" size="sm" onClick={onToggleSimulation}>
          {isSimulating ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
          {isSimulating ? 'Pause' : 'Simulate'}
        </Button>
        <Button variant="outline" size="sm" onClick={onImport}>
          <Upload className="mr-2 h-4 w-4" />
          Import JSON
        </Button>
        <Button variant="outline" size="sm" onClick={onExport}>
          <Download className="mr-2 h-4 w-4" />
          Export JSON
        </Button>
        <Button variant="outline" size="sm" onClick={onExportSvg}>
          <FileImage className="mr-2 h-4 w-4" />
          Export SVG
        </Button>
        <Button variant="outline" size="sm" onClick={onClear}>
            <Trash2 className="mr-2 h-4 w-4" />
            Clear
        </Button>
        <ThemeToggle />
      </div>
    </header>
  );
}
