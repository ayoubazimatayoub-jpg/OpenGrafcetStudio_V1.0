'use client';

import { useEffect, useRef } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import type { GrafcetDiagram, GrafcetVariable, GrafcetStep, GrafcetTransition, GrafcetAction, GrafcetReference } from '@/lib/types';
import AISuggestions from './ai-suggestions';
import type { SelectedElement } from '@/app/page';
import { Trash2, PlusCircle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

interface RightPanelProps {
  diagram: GrafcetDiagram;
  setDiagram: (diagram: GrafcetDiagram, overwriteHistory?: boolean) => void;
  selectedElement: SelectedElement | null;
  onVariableChange: (name: string) => void;
  traceLog: string[];
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const actionSchema = z.object({
  variable: z.string().min(1),
  logic: z.string().min(1),
  type: z.enum(['CONTINUOUS', 'PULSE', 'STORED']),
});

const stepSchema = z.object({
  label: z.string().min(1, 'Label is required'),
  position: z.object({
    x: z.coerce.number(),
    y: z.coerce.number(),
  }),
  actions: z.array(actionSchema),
  width: z.coerce.number().optional(),
});

const transitionSchema = z.object({
  condition: z.string().min(1, 'Condition is required'),
  position: z.object({
    x: z.coerce.number(),
    y: z.coerce.number(),
  }),
});

const referenceSchema = z.object({
  targetLabel: z.string().min(1, 'Target label is required'),
  position: z.object({
    x: z.coerce.number(),
    y: z.coerce.number(),
  }),
});

const getSchemaForElement = (type: SelectedElement['type'] | undefined) => {
  switch (type) {
    case 'step': return stepSchema;
    case 'transition': return transitionSchema;
    case 'reference': return referenceSchema;
    default: return z.object({});
  }
};

const ElementProperties = ({ diagram, setDiagram, selectedElement }: Omit<RightPanelProps, 'onVariableChange' | 'traceLog' | 'isCollapsed' | 'onToggleCollapse'>) => {
  const element = selectedElement
    ? selectedElement.type === 'step'
      ? diagram.steps.find(s => s.id === selectedElement.id)
      : selectedElement.type === 'transition'
        ? diagram.transitions.find(t => t.id === selectedElement.id)
        : diagram.references.find(r => r.id === selectedElement.id)
    : null;

  const { register, handleSubmit, reset, control, watch, formState: { errors } } = useForm({
    resolver: zodResolver(getSchemaForElement(selectedElement?.type)),
    defaultValues: element || {},
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "actions"
  });

  useEffect(() => {
    if (element) {
      reset(element);
    } else {
      reset({});
    }
  }, [element, reset]);

  const updateTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const subscription = watch((value, { name, type }) => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
      if (type === 'change' && element && selectedElement) {
        updateTimeoutRef.current = setTimeout(() => {
          const newDiagram = JSON.parse(JSON.stringify(diagram));
          
          if (selectedElement.type === 'step') {
            const stepIndex = newDiagram.steps.findIndex((s: GrafcetStep) => s.id === selectedElement.id);
            if (stepIndex !== -1) {
              if(newDiagram.steps[stepIndex].type.startsWith('AND')){
                value.label = '';
              }
              newDiagram.steps[stepIndex] = { ...newDiagram.steps[stepIndex], ...value };
            }
          } else if (selectedElement.type === 'transition') {
            const transIndex = newDiagram.transitions.findIndex((t: GrafcetTransition) => t.id === selectedElement.id);
            if (transIndex !== -1) {
              newDiagram.transitions[transIndex] = { ...newDiagram.transitions[transIndex], ...value };
            }
          } else if (selectedElement.type === 'reference') {
            const refIndex = newDiagram.references.findIndex((r: GrafcetReference) => r.id === selectedElement.id);
            if (refIndex !== -1) {
              newDiagram.references[refIndex] = { ...newDiagram.references[refIndex], ...value };
            }
          }
          
          const isPositionChange = name?.includes('position');
          setDiagram(newDiagram, !isPositionChange);
        }, 300); // Debounce updates
      }
    });
    return () => {
      subscription.unsubscribe();
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, [watch, diagram, selectedElement, setDiagram, element]);
  
  if (!selectedElement || !element) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-4">
        <p className="text-sm text-muted-foreground">Select an element on the canvas to see its properties, or multiple to align them.</p>
      </div>
    );
  }
  
  const getElementTitle = () => {
    if (selectedElement.type === 'step' && 'type' in element && element.type.startsWith('AND')) {
        return element.type.replace('_', ' ');
    }
    if (selectedElement.type === 'reference' && 'type' in element) {
        return element.type.replace('_', ' ');
    }
    return selectedElement.type;
  }

  const isStep = selectedElement.type === 'step' && 'actions' in element;
  const isAndElement = isStep && (element as GrafcetStep).type.startsWith('AND');
  const isNormalStep = isStep && !isAndElement;
  const isReference = selectedElement.type === 'reference';

  return (
    <form className="p-4 space-y-4 h-full flex flex-col">
      <div className="space-y-1">
        <h3 className="font-semibold text-lg capitalize">{getElementTitle()} Properties</h3>
        <p className="text-xs text-muted-foreground font-mono">{element.id}</p>
      </div>
      <Separator />
      
      <div className="flex-1 space-y-4 overflow-auto pr-2">
        {isNormalStep && (
          <div className="space-y-2">
            <Label htmlFor="label">Label</Label>
            <Input id="label" {...register('label')} />
            {errors.label && <p className="text-xs text-destructive mt-1">{(errors.label as any).message}</p>}
          </div>
        )}

        {isAndElement && (
           <div className="space-y-2">
            <Label htmlFor="width">Width</Label>
            <Input id="width" type="number" {...register('width')} />
          </div>
        )}

        {selectedElement.type === 'transition' && (
          <div className="space-y-2">
            <Label htmlFor="condition">Condition</Label>
            <Input id="condition" {...register('condition')} />
            <p className="text-xs text-muted-foreground pt-1">
              Use `.` for AND, `+` for OR, `/` for NOT. Ex: `Sensor_A . (/Sensor_B + Start)`
            </p>
             {errors.condition && <p className="text-xs text-destructive mt-1">{(errors.condition as any).message}</p>}
          </div>
        )}

        {isReference && (
          <div className="space-y-2">
            <Label htmlFor="targetLabel">Target Step Label</Label>
            <Input id="targetLabel" {...register('targetLabel')} />
            {errors.targetLabel && <p className="text-xs text-destructive mt-1">{(errors.targetLabel as any).message}</p>}
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="position.x">Position X</Label>
            <Input id="position.x" type="number" {...register('position.x')} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="position.y">Position Y</Label>
            <Input id="position.y" type="number" {...register('position.y')} />
          </div>
        </div>

        {isNormalStep && (
          <div className="space-y-4">
            <Separator />
            <div className="flex justify-between items-center">
              <h4 className="font-semibold">Actions</h4>
              <Button size="sm" variant="outline" type="button" onClick={() => append({ variable: '', logic: '1', type: 'CONTINUOUS' })}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add
              </Button>
            </div>
            {fields.map((field, index) => (
              <div key={field.id} className="flex items-end gap-2 p-2 border rounded-md">
                <div className="grid gap-2 flex-1">
                  <div className="space-y-1">
                    <Label>Variable</Label>
                    <Controller
                      control={control}
                      name={`actions.${index}.variable`}
                      render={({ field }) => (
                        <Select onValueChange={field.onChange} value={field.value}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select variable" />
                          </SelectTrigger>
                          <SelectContent>
                            {diagram.variables.map(v => (
                              <SelectItem key={v.name} value={v.name}>{v.name} ({v.alias || v.type})</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    />
                  </div>
                   <div className="space-y-1">
                    <Label>Value</Label>
                    <Input {...register(`actions.${index}.logic`)} />
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" type="button" onClick={() => remove(index)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

    </form>
  );
};


const SimulationPanel = ({ diagram, onVariableChange, traceLog }: { diagram: GrafcetDiagram, onVariableChange: (name: string) => void, traceLog: string[] }) => {
  const inputVariables = diagram.variables.filter(v => v.type === 'I');
  return (
    <div className="flex flex-col h-full">
      <h3 className="p-4 font-semibold text-foreground">Inputs</h3>
      <ScrollArea className="px-4">
        <div className="space-y-4">
          {inputVariables.length > 0 ? inputVariables.map(variable => (
            <div key={variable.name} className="flex items-center justify-between">
              <div>
                <Label htmlFor={variable.name} className="font-mono">{variable.name}</Label>
                {variable.alias && <p className="text-xs text-muted-foreground">{variable.alias}</p>}
              </div>
              <Switch
                id={variable.name}
                checked={!!variable.value}
                onCheckedChange={() => onVariableChange(variable.name)}
              />
            </div>
          )) : (
            <p className="text-sm text-muted-foreground text-center">No input variables defined.</p>
          )}
        </div>
      </ScrollArea>
      <Separator className="my-4"/>
      <h3 className="px-4 font-semibold text-foreground">Trace Log</h3>
      <ScrollArea className="flex-1 px-4">
        <div className="font-mono text-sm text-muted-foreground">
          {traceLog.map((stepId, index) => {
            const step = diagram.steps.find(s => s.id === stepId)
            return (
              <div key={`${stepId}-${index}`} className="flex items-center gap-2">
                <span>{`> ${step?.label || stepId}`}</span>
              </div>
            )
          })}
        </div>
      </ScrollArea>
    </div>
  );
};


export default function RightPanel({ diagram, setDiagram, selectedElement, onVariableChange, traceLog, isCollapsed, onToggleCollapse }: RightPanelProps) {
  const defaultTab = selectedElement ? "properties" : "simulation";
  
  return (
    <Card className="h-full w-96 border-l border-t-0 rounded-none shadow-md">
      <Tabs defaultValue="simulation" value={selectedElement ? "properties" : "simulation"} className="flex flex-col h-full">
        <TabsList className="grid w-full grid-cols-3 rounded-none">
          <TabsTrigger value="properties" disabled={!selectedElement}>Properties</TabsTrigger>
          <TabsTrigger value="simulation">Simulation</TabsTrigger>
          <TabsTrigger value="ai">AI Helper</TabsTrigger>
        </TabsList>
        <TabsContent value="properties" className="flex-1 overflow-hidden p-0 m-0">
          <ElementProperties diagram={diagram} setDiagram={setDiagram} selectedElement={selectedElement} />
        </TabsContent>
        <TabsContent value="simulation" className="flex-1 overflow-hidden p-0 m-0">
          <SimulationPanel diagram={diagram} onVariableChange={onVariableChange} traceLog={traceLog} />
        </TabsContent>
        <TabsContent value="ai" className="flex-1 overflow-hidden p-4 m-0">
          <AISuggestions diagram={diagram} />
        </TabsContent>
      </Tabs>
    </Card>
  );
}
