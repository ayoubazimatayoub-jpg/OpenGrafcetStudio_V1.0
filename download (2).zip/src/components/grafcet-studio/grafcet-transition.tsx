'use client';

import type { GrafcetTransition as GrafcetTransitionType } from '@/lib/types';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { Button } from '../ui/button';
import { X, Link2 } from 'lucide-react';

interface GrafcetTransitionProps {
  transition: GrafcetTransitionType;
  isSelected: boolean;
  isLinkingFrom: boolean;
  onDragStart: (e: React.DragEvent, transitionId: string) => void;
  onDelete: (id: string) => void;
  onConnectorClick: (e: React.MouseEvent, id: string) => void;
  onClick: (e: React.MouseEvent, id: string) => void;
}

const TRANSITION_WIDTH = 60;
const TRANSITION_HEIGHT = 12;

export default function GrafcetTransition({ transition, isSelected, isLinkingFrom, onDragStart, onDelete, onConnectorClick, onClick }: GrafcetTransitionProps) {
  return (
    <TooltipProvider>
        <Tooltip>
            <TooltipTrigger asChild>
                <div
                    draggable
                    onDragStart={(e) => onDragStart(e, transition.id)}
                    onClick={(e) => onClick(e, transition.id)}
                    className={cn(
                      "absolute cursor-grab active:cursor-grabbing group flex items-center",
                      isLinkingFrom && "z-10",
                      isSelected && "z-10"
                    )}
                    style={{
                      left: transition.position.x,
                      top: transition.position.y,
                    }}
                >
                    <div className="relative" style={{ width: TRANSITION_WIDTH, height: TRANSITION_HEIGHT }}>
                        <div className={cn(
                        "absolute top-1/2 left-0 w-full h-0.5",
                        isLinkingFrom && "bg-blue-500",
                        isSelected ? "bg-primary" : "bg-foreground"
                        )} />
                        <div className={cn(
                        "absolute left-1/2 top-0 w-0.5 h-full",
                        isLinkingFrom && "bg-blue-500",
                        isSelected ? "bg-primary" : "bg-foreground"
                        )} />
                        <Button
                            variant="destructive"
                            size="icon"
                            className="absolute -top-2 -right-2 h-6 w-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-20"
                            onClick={(e) => {
                                e.stopPropagation();
                                onDelete(transition.id);
                            }}
                        >
                            <X className="h-4 w-4" />
                        </Button>
                        <div 
                        className="absolute -bottom-2 left-1/2 -translate-x-1/2 h-6 w-6 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20"
                        onClick={(e) => onConnectorClick(e, transition.id)}
                        >
                        <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6 rounded-full bg-background hover:bg-accent"
                        >
                            <Link2 className="h-4 w-4" />
                        </Button>
                        </div>
                    </div>
                    {transition.condition && (
                        <div className="pl-2 font-mono text-xs w-48 whitespace-pre-wrap">
                            {transition.condition}
                        </div>
                    )}
                </div>
            </TooltipTrigger>
            <TooltipContent>
                <p className="font-semibold">Transition: <span className="font-mono">{transition.condition}</span></p>
            </TooltipContent>
        </Tooltip>
    </TooltipProvider>
  );
}
