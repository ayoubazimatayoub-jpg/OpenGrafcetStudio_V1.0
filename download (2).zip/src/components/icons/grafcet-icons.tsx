import { cn } from "@/lib/utils";

type IconProps = {
  className?: string;
};

export const InitialStepIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <rect x="2" y="2" width="20" height="20" />
    <rect x="6" y="6" width="12" height="12" />
  </svg>
);

export const StepIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <rect x="3" y="3" width="18" height="18" />
  </svg>
);

export const TransitionIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <line x1="4" y1="12" x2="20" y2="12" />
    <line x1="12" y1="5" x2="12" y2="19" />
  </svg>
);

export const AndDivergenceIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <line x1="12" y1="2" x2="12" y2="10" />
    <line x1="4" y1="10" x2="20" y2="10" />
    <line x1="4" y1="10" x2="20" y2="10" transform="translate(0, 2)" />
    <line x1="6" y1="12" x2="6" y2="20" />
    <line x1="18" y1="12" x2="18" y2="20" />
  </svg>
);

export const AndConvergenceIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <line x1="6" y1="4" x2="6" y2="12" />
    <line x1="18" y1="4" x2="18" y2="12" />
    <line x1="4" y1="12" x2="20" y2="12" />
    <line x1="4" y1="12" x2="20" y2="12" transform="translate(0, 2)" />
    <line x1="12" y1="14" x2="12" y2="22" />
  </svg>
);

export const ReferenceInIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <path d="M12 2L12 14" />
    <path d="M5 9L12 2L19 9" />
    <path d="M5 22H19" />
  </svg>
);
  
export const ReferenceOutIcon = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cn(className)}>
    <path d="M5 2H19" />
    <path d="M12 10L12 22" />
    <path d="M5 15L12 22L19 15" />
  </svg>
);
