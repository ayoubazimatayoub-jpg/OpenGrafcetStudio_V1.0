'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import type { GrafcetDiagram, GrafcetStep, GrafcetTransition, GrafcetReference } from '@/lib/types';
import { initialDiagram } from '@/lib/grafcet-data';
import StudioHeader from '@/components/grafcet-studio/studio-header';
import LeftPanel from '@/components/grafcet-studio/left-panel';
import RightPanel from '@/components/grafcet-studio/right-panel';
import GrafcetCanvas from '@/components/grafcet-studio/grafcet-canvas';
import { cn } from '@/lib/utils';
import { generateSvgString } from '@/lib/svg-export';
import { Button } from '@/components/ui/button';
import { PanelLeftClose, PanelRightClose, PanelLeftOpen, PanelRightOpen } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from '@/hooks/use-toast';


type LinkingState = {
  fromId: string;
  fromType: 'step' | 'transition' | 'reference';
};

export type SelectedElement = {
  id: string;
  type: 'step' | 'transition' | 'reference';
};

export default function Home() {
  const [diagram, setDiagram] = useState<GrafcetDiagram>(initialDiagram);
  const [activeSteps, setActiveSteps] = useState<string[]>(
    initialDiagram.steps.filter(s => s.type === 'STEP_INITIAL').map(s => s.id)
  );
  const [isSimulating, setIsSimulating] = useState(false);
  const [history, setHistory] = useState<GrafcetDiagram[]>([initialDiagram]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [linkingState, setLinkingState] = useState<LinkingState | null>(null);
  const [selectedElements, setSelectedElements] = useState<SelectedElement[]>([]);
  const [isLeftPanelCollapsed, setIsLeftPanelCollapsed] = useState(false);
  const [isRightPanelCollapsed, setIsRightPanelCollapsed] = useState(false);
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);
  const { toast } = useToast();

  const dragStartPositions = useRef<Map<string, {x: number, y: number}>>(new Map());
  const dragStartMousePosition = useRef({ x: 0, y: 0 });
  const dragOffset = useRef({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);
  const importFileRef = useRef<HTMLInputElement>(null);

  const updateDiagram = useCallback((newDiagram: GrafcetDiagram, overwriteHistory: boolean = false) => {
    const currentDiagramJSON = JSON.stringify(history[historyIndex]);
    const newDiagramJSON = JSON.stringify(newDiagram);

    if (currentDiagramJSON === newDiagramJSON) {
      return;
    }

    let newHistory: GrafcetDiagram[];
    let newIndex: number;

    const updatedDiagram = JSON.parse(JSON.stringify(newDiagram));

    if (overwriteHistory) {
      newHistory = [...history];
      newHistory[historyIndex] = updatedDiagram;
      newIndex = historyIndex;
    } else {
      const futureHistory = history.slice(historyIndex + 1);
      const isRedo = futureHistory.some(hist => JSON.stringify(hist) === newDiagramJSON);
      if (isRedo) {
        newHistory = history;
        newIndex = history.findIndex(hist => JSON.stringify(hist) === newDiagramJSON);
      } else {
        const pastHistory = history.slice(0, historyIndex + 1);
        newHistory = [...pastHistory, updatedDiagram];
        newIndex = newHistory.length - 1;
      }
    }
    
    setHistory(newHistory);
    setHistoryIndex(newIndex);
    setDiagram(updatedDiagram);
  }, [history, historyIndex]);

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  const handleUndo = useCallback(() => {
    if (canUndo) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setDiagram(history[newIndex]);
    }
  }, [canUndo, history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (canRedo) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setDiagram(history[newIndex]);
    }
  }, [canRedo, history, historyIndex]);
  
  const handleSelectAll = useCallback(() => {
    const allElements = [
      ...diagram.steps.map(s => ({ id: s.id, type: 'step' as const })),
      ...diagram.transitions.map(t => ({ id: t.id, type: 'transition' as const })),
      ...diagram.references.map(r => ({ id: r.id, type: 'reference' as const })),
    ];
    setSelectedElements(allElements);
  }, [diagram.steps, diagram.transitions, diagram.references]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'z') {
          e.preventDefault();
          if (e.shiftKey) {
            handleRedo();
          } else {
            handleUndo();
          }
        } else if (e.key === 'y') {
          e.preventDefault();
          handleRedo();
        } else if (e.key === 'a') {
          e.preventDefault();
          handleSelectAll();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo, handleSelectAll]);

  const handleDragStart = (e: React.DragEvent, id: string, type: 'step' | 'transition' | 'reference') => {
    dragStartMousePosition.current = { x: e.clientX, y: e.clientY };
  
    const isGroupDrag = selectedElements.length > 1 && selectedElements.some(el => el.id === id);
    const draggedElements = isGroupDrag ? selectedElements : [{ id, type }];
  
    dragStartPositions.current.clear();
    draggedElements.forEach(draggedEl => {
      let el;
      if (draggedEl.type === 'step') {
        el = diagram.steps.find(s => s.id === draggedEl.id);
      } else if (draggedEl.type === 'transition') {
        el = diagram.transitions.find(t => t.id === draggedEl.id);
      } else {
        el = diagram.references.find(r => r.id === draggedEl.id);
      }
      
      if (el) {
        dragStartPositions.current.set(draggedEl.id, { ...el.position });
      }
    });
  
    e.dataTransfer.setData('application/grafcet-element', JSON.stringify({ id, type, isGroup: isGroupDrag, new: false }));
  };

  const handleSymbolDragStart = (e: React.DragEvent, symbolType: string) => {
    e.dataTransfer.setData('application/grafcet-element', JSON.stringify({ type: symbolType, new: true }));
    dragOffset.current = { x: 40, y: 40 }; // Center of symbol
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const data = e.dataTransfer.getData('application/grafcet-element');
    if (!data || !canvasRef.current) return;
  
    const droppedElement = JSON.parse(data);
    const canvasRect = canvasRef.current.getBoundingClientRect();
    let x = e.clientX - canvasRect.left;
    let y = e.clientY - canvasRect.top;
  
    const newDiagram = JSON.parse(JSON.stringify(diagram));
    let newElementId: string | null = null;
    let newElementType: 'step' | 'transition' | 'reference' | null = null;
  
    if (droppedElement.new) {
        x -= dragOffset.current.x;
        y -= dragOffset.current.y;
      const lastSelected = selectedElements.length > 0 ? selectedElements[selectedElements.length - 1] : null;
      if (droppedElement.type.startsWith('STEP') || droppedElement.type.startsWith('AND')) {
        const newStep: GrafcetStep = {
          id: `step_${Date.now()}`,
          type: droppedElement.type,
          label: droppedElement.type.startsWith('AND') ? '' : `${newDiagram.steps.filter((s: GrafcetStep) => !s.type.startsWith('AND')).length + 1}`,
          position: { x, y },
          actions: [],
          connectedTo: [],
        };
        newDiagram.steps.push(newStep);
        newElementId = newStep.id;
        newElementType = 'step';

        if (lastSelected?.type === 'transition') {
          const fromTransition = newDiagram.transitions.find((t: GrafcetTransition) => t.id === lastSelected.id);
          if (fromTransition) {
            fromTransition.connectedTo.push(newElementId);
          }
        }

      } else if (droppedElement.type === 'TRANSITION') {
        const newTransition: GrafcetTransition = {
          id: `trans_${Date.now()}`,
          label: `t${newDiagram.transitions.length + 1}`,
          position: { x, y },
          condition: 'true',
          connectedTo: [],
        };
        newDiagram.transitions.push(newTransition);
        newElementId = newTransition.id;
        newElementType = 'transition';

        if (lastSelected?.type === 'step') {
            const fromStep = newDiagram.steps.find((s: GrafcetStep) => s.id === lastSelected.id);
            if (fromStep) {
                fromStep.connectedTo.push(newElementId);
            }
        }
      } else if (droppedElement.type.startsWith('REFERENCE')) {
        const newRef: GrafcetReference = {
          id: `ref_${Date.now()}`,
          type: droppedElement.type,
          position: { x, y },
          targetLabel: '?',
          connectedTo: [],
        };
        newDiagram.references.push(newRef);
        newElementId = newRef.id;
        newElementType = 'reference';

        const fromElement = lastSelected
          ? lastSelected.type === 'step'
            ? newDiagram.steps.find((s: GrafcetStep) => s.id === lastSelected.id)
            : newDiagram.transitions.find((t: GrafcetTransition) => t.id === lastSelected.id)
          : null;

        if (fromElement) {
            fromElement.connectedTo.push(newElementId);
        }
      }
    } else {
        const deltaX = e.clientX - dragStartMousePosition.current.x;
        const deltaY = e.clientY - dragStartMousePosition.current.y;

        const elementsToMove = droppedElement.isGroup ? selectedElements : [droppedElement];

        elementsToMove.forEach(elInfo => {
            let element;
            if (elInfo.type === 'step') {
              element = newDiagram.steps.find((s: GrafcetStep) => s.id === elInfo.id);
            } else if (elInfo.type === 'transition') {
              element = newDiagram.transitions.find((t: GrafcetTransition) => t.id === elInfo.id);
            } else {
              element = newDiagram.references.find((r: GrafcetReference) => r.id === elInfo.id);
            }

            const originalPos = dragStartPositions.current.get(elInfo.id);

            if (element && originalPos) {
                element.position.x = originalPos.x + deltaX;
                element.position.y = originalPos.y + deltaY;
            }
        });
    }
    
    updateDiagram(newDiagram);
    if (newElementId && newElementType) {
      setSelectedElements([{ id: newElementId, type: newElementType }]);
    }
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };
  
  const handleElementClick = (e: React.MouseEvent, id: string, type: 'step' | 'transition' | 'reference') => {
    e.stopPropagation();
    const newSelection = { id, type };
    if (linkingState) {
      const newDiagram = JSON.parse(JSON.stringify(diagram));
      const { fromId, fromType } = linkingState;

      const fromElement = fromType === 'step' 
        ? newDiagram.steps.find((s: GrafcetStep) => s.id === fromId)
        : fromType === 'transition'
          ? newDiagram.transitions.find((t: GrafcetTransition) => t.id === fromId)
          : newDiagram.references.find((r: GrafcetReference) => r.id === fromId);

      if (fromElement) {
        if (!fromElement.connectedTo.includes(id)) {
          fromElement.connectedTo.push(id);
        }
      }
      
      updateDiagram(newDiagram);
      setLinkingState(null);
      setSelectedElements([]);
    } else if (e.shiftKey) {
        setSelectedElements(prev => {
            const isSelected = prev.some(el => el.id === id);
            if (isSelected) {
                return prev.filter(el => el.id !== id);
            } else {
                return [...prev, newSelection];
            }
        });
    } else {
      const isAlreadySelected = selectedElements.length === 1 && selectedElements[0].id === id;
      if (!isAlreadySelected) {
        setSelectedElements([newSelection]);
      }
    }
  };
  
  const handleConnectorClick = (e: React.MouseEvent, id: string, type: 'step' | 'transition' | 'reference') => {
    e.stopPropagation();
    setLinkingState({ fromId: id, fromType: type });
    setSelectedElements([]);
  };

  const handleDeleteElement = (id: string, type: 'step' | 'transition' | 'reference') => {
    const newDiagram = JSON.parse(JSON.stringify(diagram));
    if (type === 'step') {
      newDiagram.steps = newDiagram.steps.filter((s: { id: string; }) => s.id !== id);
    } else if (type === 'transition') {
      newDiagram.transitions = newDiagram.transitions.filter((t: { id: string; }) => t.id !== id);
    } else if (type === 'reference') {
      newDiagram.references = newDiagram.references.filter((r: { id: string; }) => r.id !== id);
    }

    [...newDiagram.steps, ...newDiagram.transitions, ...newDiagram.references].forEach(el => {
      el.connectedTo = el.connectedTo.filter((connectedId: string) => connectedId !== id);
    });
    
    updateDiagram(newDiagram);
    setSelectedElements([]);
  };

  const handleClearDiagram = () => {
    const clearedDiagram: GrafcetDiagram = {
        projectInfo: diagram.projectInfo,
        steps: [],
        transitions: [],
        references: [],
        variables: diagram.variables 
    };
    updateDiagram(clearedDiagram);
    setActiveSteps([]);
    setSelectedElements([]);
    setIsClearConfirmOpen(false);
  };

  const handleAlignment = (alignment: string) => {
    if (selectedElements.length < 2) return;
  
    const newDiagram = JSON.parse(JSON.stringify(diagram));
    const selectedItems = selectedElements.map(sel => {
      if (sel.type === 'step') return newDiagram.steps.find((s: GrafcetStep) => s.id === sel.id);
      if (sel.type === 'transition') return newDiagram.transitions.find((t: GrafcetTransition) => t.id === sel.id);
      if (sel.type === 'reference') return newDiagram.references.find((r: GrafcetReference) => r.id === sel.id);
    }).filter(Boolean);
  
    if (selectedItems.length < 2) return;

    const getItemHeight = (item: any) => {
      if (item.type && (item.type === 'STEP_INITIAL' || item.type === 'STEP_NORMAL')) return 60;
      if (item.type && item.type.startsWith('AND')) return 12;
      return 12;
    };
  
    switch (alignment) {
      case 'left':
        const leftX = Math.min(...selectedItems.map(item => item.position.x));
        selectedItems.forEach(item => item.position.x = leftX);
        break;
      case 'center-v':
        const centerV = selectedItems.reduce((sum, item) => sum + item.position.x, 0) / selectedItems.length;
        selectedItems.forEach(item => item.position.x = centerV);
        break;
      case 'right':
        const rightX = Math.max(...selectedItems.map(item => item.position.x));
        selectedItems.forEach(item => item.position.x = rightX);
        break;
      case 'top':
        const topY = Math.min(...selectedItems.map(item => item.position.y));
        selectedItems.forEach(item => item.position.y = topY);
        break;
      case 'center-h':
        const centerH = selectedItems.reduce((sum, item) => sum + item.position.y, 0) / selectedItems.length;
        selectedItems.forEach(item => item.position.y = centerH);
        break;
      case 'bottom':
        const bottomY = Math.max(...selectedItems.map(item => item.position.y + getItemHeight(item)));
        selectedItems.forEach(item => item.position.y = bottomY - getItemHeight(item));
        break;
      case 'distribute-h':
        if (selectedItems.length > 2) {
          const sortedH = selectedItems.sort((a, b) => a.position.x - b.position.x);
          const minX = sortedH[0].position.x;
          const maxX = sortedH[sortedH.length - 1].position.x;
          const space = (maxX - minX) / (sortedH.length - 1);
          sortedH.forEach((item, index) => item.position.x = minX + index * space);
        }
        break;
      case 'distribute-v':
        if (selectedItems.length > 2) {
          const sortedV = selectedItems.sort((a, b) => a.position.y - b.position.y);
          const minY = sortedV[0].position.y;
          const maxY = sortedV[sortedV.length - 1].position.y;
          const space = (maxY - minY) / (sortedV.length - 1);
          sortedV.forEach((item, index) => item.position.y = minY + index * space);
        }
        break;
    }
  
    updateDiagram(newDiagram, true);
  };

  const toggleVariable = (name: string) => {
    const newDiagram = JSON.parse(JSON.stringify(diagram));
    const variable = newDiagram.variables.find((v: { name: string; }) => v.name === name);
    if (variable && variable.type === 'I') {
      variable.value = !variable.value;
      updateDiagram(newDiagram, true);
    }
  };

  const handleImport = () => {
    importFileRef.current?.click();
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result;
        if (typeof content !== 'string') {
            throw new Error("File content is not a string");
        }
        const importedDiagram = JSON.parse(content);
        // Basic validation
        if (importedDiagram.projectInfo && importedDiagram.steps && importedDiagram.transitions && importedDiagram.variables) {
            if (!importedDiagram.references) {
              importedDiagram.references = [];
            }
            updateDiagram(importedDiagram);
            setActiveSteps(importedDiagram.steps.filter((s: GrafcetStep) => s.type === 'STEP_INITIAL').map((s: GrafcetStep) => s.id));
            setSelectedElements([]);
            toast({
                title: "Import Successful",
                description: "The GRAFCET diagram has been loaded.",
            });
        } else {
            throw new Error("Invalid JSON structure for a GRAFCET diagram.");
        }
      } catch (error) {
        console.error("Failed to import file:", error);
        toast({
            variant: "destructive",
            title: "Import Failed",
            description: "The selected file is not a valid GRAFCET diagram JSON file.",
        });
      }
    };
    reader.readAsText(file);

    // Reset input value to allow importing the same file again
    event.target.value = '';
  };


  const handleExport = () => {
    const dataStr = JSON.stringify(diagram, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = 'grafcet-diagram.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };
  
  const handleExportSvg = () => {
    const isDarkMode = document.documentElement.classList.contains('dark');
    const svgString = generateSvgString(diagram, isDarkMode);
    const dataUri = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgString);
    const exportFileDefaultName = 'grafcet-diagram.svg';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const simulationTick = useCallback(() => {
    let newActiveSteps = [...activeSteps];
    let changed = false;

    const currentDiagram = history[historyIndex];

    const evaluateCondition = (condition: string) => {
        if (condition.toLowerCase() === 'true') return true;
        if (condition.toLowerCase() === 'false') return false;

        const variableValues: { [key: string]: boolean } = {};
        currentDiagram.variables.forEach(v => {
            variableValues[v.name] = !!v.value;
        });

        // Replace operators: AND -> &&, OR -> ||, NOT -> !
        // Use more symbolic operators: . for AND, + for OR, / for NOT
        const jsCondition = condition
            .replace(/\./g, '&&')
            .replace(/\+/g, '||')
            .replace(/\//g, '!')
            .replace(/AND/gi, '&&')
            .replace(/OR/gi, '||')
            .replace(/NOT/gi, '!');

        try {
            const func = new Function(...Object.keys(variableValues), `return ${jsCondition};`);
            return func(...Object.values(variableValues));
        } catch (e) {
            console.error('Error evaluating condition:', condition, e);
            return false;
        }
    };
    
    // Simulate references as transitions
    const referenceTransitions: GrafcetTransition[] = currentDiagram.references
        .filter(ref => ref.type === 'REFERENCE_OUT')
        .map(ref => {
            const targetStep = currentDiagram.steps.find(s => s.label === ref.targetLabel);
            return {
                id: ref.id,
                condition: 'true', // Always true
                connectedTo: targetStep ? [targetStep.id] : [],
                label: `ref_to_${ref.targetLabel}`,
                position: {x:0, y:0}
            };
        });

    activeSteps.forEach(activeStepId => {
      const step = currentDiagram.steps.find(s => s.id === activeStepId);
      if (!step) return;

      const connectedTransitionIds = step.connectedTo.map(id => {
        if (currentDiagram.transitions.find(t => t.id === id)) return id;
        if (currentDiagram.references.find(r => r.id === id && r.type === 'REFERENCE_OUT')) return id;
        return null;
      }).filter(Boolean) as string[];


      const transitions = connectedTransitionIds.map(id => {
          const t = currentDiagram.transitions.find(t => t.id === id);
          if (t) return t;
          const r = currentDiagram.references.find(r => r.id === id);
          if (r) {
            const targetStep = currentDiagram.steps.find(s => s.label === r.targetLabel);
            return {
              id: r.id,
              condition: 'true',
              connectedTo: targetStep ? [targetStep.id] : [],
            }
          }
          return null;
      }).filter(Boolean) as (GrafcetTransition | { id: string, condition: string, connectedTo: string[]})[];

      const fireableTransitions = transitions.filter(t => evaluateCondition(t.condition));

      if (fireableTransitions.length > 0) {
          // Check if we are trying to activate already active steps
          const allNextStepsAreActive = fireableTransitions.every(t =>
              t.connectedTo.every(nextStepId => activeSteps.includes(nextStepId))
          );
          
          if (!allNextStepsAreActive) {
            newActiveSteps = newActiveSteps.filter(id => id !== activeStepId);
            fireableTransitions.forEach(transition => {
                transition.connectedTo.forEach(nextStepId => {
                    if (!newActiveSteps.includes(nextStepId)) {
                        newActiveSteps.push(nextStepId);
                    }
                });
            });
            changed = true;
          }
      }
    });

    if (changed) {
      setActiveSteps(newActiveSteps);
    }
  }, [activeSteps, history, historyIndex]);

  useEffect(() => {
    if (isSimulating) {
      const timer = setInterval(() => {
        simulationTick();
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isSimulating, simulationTick]);

  useEffect(() => {
    if (isSimulating) {
      simulationTick();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [diagram.variables, isSimulating]);

  return (
    <div className="flex h-screen w-full flex-col font-body">
      <input
        type="file"
        ref={importFileRef}
        className="hidden"
        accept="application/json"
        onChange={handleFileImport}
      />
      <StudioHeader 
        onImport={handleImport}
        onExport={handleExport} 
        onExportSvg={handleExportSvg}
        isSimulating={isSimulating} 
        onToggleSimulation={() => setIsSimulating(!isSimulating)}
        onClear={() => setIsClearConfirmOpen(true)}
        selectedElementCount={selectedElements.length}
        onAlign={handleAlignment}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        onSelectAll={handleSelectAll}
      />
      <main className="flex flex-1 overflow-hidden">
        {!isLeftPanelCollapsed && (
            <LeftPanel 
                diagram={diagram} 
                setDiagram={updateDiagram} 
                onDragStart={handleSymbolDragStart}
                isCollapsed={isLeftPanelCollapsed}
                onToggleCollapse={() => setIsLeftPanelCollapsed(!isLeftPanelCollapsed)}
            />
        )}
        <div className="flex flex-col flex-1 overflow-hidden">
            <div className="flex items-center gap-2 p-1 bg-background border-b border-t">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsLeftPanelCollapsed(!isLeftPanelCollapsed)}>
                    {isLeftPanelCollapsed ? <PanelLeftOpen /> : <PanelLeftClose />}
                </Button>
                <div className="flex-1" />
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsRightPanelCollapsed(!isRightPanelCollapsed)}>
                    {isRightPanelCollapsed ? <PanelRightOpen /> : <PanelRightClose />}
                </Button>
            </div>
            <div 
            ref={canvasRef}
            className={cn(
                "flex-1 overflow-auto relative bg-card dark:bg-background",
                linkingState && "cursor-crosshair"
            )}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => {
                setLinkingState(null);
                setSelectedElements([]);
            }}
            >
            <GrafcetCanvas 
                diagram={diagram} 
                activeSteps={activeSteps}
                linkingState={linkingState}
                selectedElements={selectedElements}
                onDragStart={handleDragStart}
                onDeleteElement={handleDeleteElement}
                onConnectorClick={handleConnectorClick}
                onElementClick={handleElementClick}
            />
            </div>
        </div>
        {!isRightPanelCollapsed && (
            <RightPanel 
                diagram={diagram}
                setDiagram={updateDiagram}
                selectedElement={selectedElements.length === 1 ? selectedElements[0] : null}
                onVariableChange={toggleVariable}
                traceLog={activeSteps}
                isCollapsed={isRightPanelCollapsed}
                onToggleCollapse={() => setIsRightPanelCollapsed(!isRightPanelCollapsed)}
            />
        )}
      </main>

       <AlertDialog open={isClearConfirmOpen} onOpenChange={setIsClearConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your
              current diagram and remove your data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleClearDiagram}>Clear Diagram</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
