'use server';

/**
 * @fileOverview AI-powered suggestions for GRAFCET diagrams.
 *
 * - getGrafcetSuggestions - A function that takes a GRAFCET diagram as input and returns AI-powered suggestions.
 * - GrafcetSuggestionsInput - The input type for the getGrafcetSuggestions function.
 * - GrafcetSuggestionsOutput - The return type for the getGrafcetSuggestions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GrafcetSuggestionsInputSchema = z.object({
  grafcetDiagram: z.string().describe('A JSON representation of the GRAFCET diagram.'),
});
export type GrafcetSuggestionsInput = z.infer<typeof GrafcetSuggestionsInputSchema>;

const GrafcetSuggestionsOutputSchema = z.object({
  suggestions: z.array(z.string()).describe('An array of AI-powered suggestions for the GRAFCET diagram.'),
});
export type GrafcetSuggestionsOutput = z.infer<typeof GrafcetSuggestionsOutputSchema>;

export async function getGrafcetSuggestions(input: GrafcetSuggestionsInput): Promise<GrafcetSuggestionsOutput> {
  return grafcetSuggestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'grafcetSuggestionsPrompt',
  input: {schema: GrafcetSuggestionsInputSchema},
  output: {schema: GrafcetSuggestionsOutputSchema},
  prompt: `You are an AI expert in GRAFCET diagrams and IEC 60848 standards. You will receive a JSON representation of a GRAFCET diagram and provide suggestions to improve its design, identify potential issues, and explore alternative approaches.

GRAFCET Diagram: {{{grafcetDiagram}}}

Provide a list of suggestions for improving the GRAFCET diagram. Consider aspects such as:
- Adherence to IEC 60848 standards
- Potential deadlocks or infinite loops
- Redundancy and optimization opportunities
- Clarity and readability
- Alternative design patterns
- Variable usage and consistency
- Potential safety issues

Suggestions:`,
});

const grafcetSuggestionsFlow = ai.defineFlow(
  {
    name: 'grafcetSuggestionsFlow',
    inputSchema: GrafcetSuggestionsInputSchema,
    outputSchema: GrafcetSuggestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
