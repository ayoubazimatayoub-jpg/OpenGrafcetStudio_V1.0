import { config } from 'dotenv';
config();

import '@/ai/flows/ai-powered-suggestions.ts';