export interface GrafcetAction {
  type: 'CONTINUOUS' | 'PULSE' | 'STORED';
  variable: string;
  logic: 'SET' | 'RESET' | string;
}

export interface GrafcetStep {
  id: string;
  type: 'STEP_INITIAL' | 'STEP_NORMAL' | 'AND_DIVERGENCE' | 'AND_CONVERGENCE';
  label: string;
  position: { x: number; y: number };
  actions: GrafcetAction[];
  connectedTo: string[];
  width?: number;
}

export interface GrafcetTransition {
  id: string;
  label: string;
  position: { x: number; y: number };
  condition: string;
  connectedTo: string[];
}

export interface GrafcetReference {
  id: string;
  type: 'REFERENCE_IN' | 'REFERENCE_OUT';
  position: { x: number; y: number };
  targetLabel: string;
  connectedTo: string[];
}

export interface GrafcetVariable {
  name: string;
  type: 'I' | 'Q' | 'T' | 'C' | 'Internal';
  alias?: string;
  value?: boolean | number;
}

export interface ProjectInfo {
  title: string;
  author: string;
  version: string;
  description: string;
}

export interface GrafcetDiagram {
  projectInfo: ProjectInfo;
  steps: GrafcetStep[];
  transitions: GrafcetTransition[];
  references: GrafcetReference[];
  variables: GrafcetVariable[];
}
