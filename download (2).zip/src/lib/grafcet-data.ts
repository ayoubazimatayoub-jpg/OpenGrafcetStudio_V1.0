import type { GrafcetDiagram } from './types';

export const initialDiagram: GrafcetDiagram = {
  projectInfo: {
    title: 'New GRAFCET Project',
    author: 'Unknown',
    version: '1.0.0',
    description: 'A new GRAFCET diagram created with Studio.',
  },
  steps: [
    {
      id: 'step_1',
      type: 'STEP_INITIAL',
      label: '1',
      position: { x: 300, y: 50 },
      actions: [],
      connectedTo: ['trans_1'],
    },
    {
      id: 'step_2',
      type: 'STEP_NORMAL',
      label: '2',
      position: { x: 300, y: 250 },
      actions: [],
      connectedTo: ['trans_2'],
    },
    {
      id: 'step_3',
      type: 'STEP_NORMAL',
      label: '3',
      position: { x: 100, y: 450 },
      actions: [],
      connectedTo: ['trans_3'],
    },
    {
      id: 'step_4',
      type: 'STEP_NORMAL',
      label: '4',
      position: { x: 500, y: 450 },
      actions: [],
      connectedTo: ['trans_4'],
    },
  ],
  transitions: [
    {
      id: 'trans_1',
      label: 't1',
      position: { x: 300, y: 150 },
      condition: 'Sensor_A',
      connectedTo: ['step_2'],
    },
    {
      id: 'trans_2',
      label: 't2',
      position: { x: 300, y: 350 },
      condition: 'Sensor_B',
      connectedTo: ['step_3', 'step_4'],
    },
    {
      id: 'trans_3',
      label: 't3',
      position: { x: 100, y: 550 },
      condition: 'Reset',
      connectedTo: ['step_1'],
    },
    {
      id: 'trans_4',
      label: 't4',
      position: { x: 500, y: 550 },
      condition: 'Reset',
      connectedTo: ['step_1'],
    },
  ],
  references: [],
  variables: [
    { name: 'Sensor_A', type: 'I', alias: 'Start Button', value: false },
    { name: 'Sensor_B', type: 'I', alias: 'Stop Button', value: false },
    { name: 'Reset', type: 'I', alias: 'Reset Cycle', value: false },
    { name: 'Motor_Up', type: 'Q', value: false },
    { name: 'Motor_Down', type: 'Q', value: false },
    { name: 'T1', type: 'T' },
    { name: 'C1', type: 'C' },
  ],
};
