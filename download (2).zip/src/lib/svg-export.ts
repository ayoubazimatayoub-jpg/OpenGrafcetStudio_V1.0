import type { GrafcetDiagram } from './types';

const STEP_SIZE = 60;
const TRANSITION_WIDTH = 60;
const TRANSITION_HEIGHT = 12;
const INITIAL_STEP_INSET = 6;
const REFERENCE_WIDTH = 50;
const REFERENCE_HEIGHT = 25;

// --- A4 Page Setup (at 96 DPI) ---
const A4_WIDTH = 794;
const A4_HEIGHT = 1123;
const MARGIN = 38; // ~10mm margin
const PRINTABLE_WIDTH = A4_WIDTH - MARGIN * 2;
const PRINTABLE_HEIGHT = A4_HEIGHT - MARGIN * 2;
const TITLE_BLOCK_HEIGHT = 85;
const DIAGRAM_AREA_HEIGHT = PRINTABLE_HEIGHT - TITLE_BLOCK_HEIGHT - 10;

// Helper to get element dimensions
function getElementDimensions(el: any) {
  if (el.type?.startsWith('STEP')) {
    return { width: STEP_SIZE, height: STEP_SIZE };
  }
  if (el.type?.startsWith('AND')) {
    return { width: el.width || STEP_SIZE, height: 12 };
  }
  if (el.type?.startsWith('REFERENCE')) {
    return { width: REFERENCE_WIDTH, height: REFERENCE_HEIGHT };
  }
  if (el.condition) { // Transition
    return { width: TRANSITION_WIDTH, height: TRANSITION_HEIGHT };
  }
  return { width: 0, height: 0 };
}


function getLinkPath(diagram: GrafcetDiagram, fromId: string, toId: string, type: 'step-to-transition' | 'transition-to-step') {
    const fromEl = diagram.steps.find(s => s.id === fromId) || diagram.transitions.find(t => t.id === fromId) || diagram.references.find(r => r.id === fromId);
    const toEl = diagram.steps.find(s => s.id === toId) || diagram.transitions.find(t => t.id === toId) || diagram.references.find(r => r.id === toId);
  
    if (!fromEl || !toEl) return '';
  
    const fromIsAnd = 'type' in fromEl && fromEl.type.startsWith('AND');
    const toIsAnd = 'type' in toEl && toEl.type.startsWith('AND');

    const getAttachmentPoint = (
        element: any,
        direction: 'top' | 'bottom',
        connectedElementId: string,
        allConnections: string[]
    ) => {
        const { width, height } = getElementDimensions(element);
        const isAndElement = element.type?.startsWith('AND');

        if (!isAndElement) {
            return { x: element.position.x + width / 2, y: element.position.y + (direction === 'top' ? 0 : height) };
        }

        const connectionIndex = allConnections.findIndex(id => id === connectedElementId);
        const totalConnections = allConnections.length;
        const spacing = width / (totalConnections + 1);
        const pointX = element.position.x + spacing * (connectionIndex + 1);

        return { x: pointX, y: element.position.y + (direction === 'top' ? 0 : height) };
    };
  
    let p1, p2;

    if (type === 'step-to-transition') {
        const predecessorElements = [...diagram.steps, ...diagram.references].filter(s => s.connectedTo.includes(toId)).map(s => s.id);
        p1 = getAttachmentPoint(fromEl, 'bottom', toId, fromEl.connectedTo);
        p2 = getAttachmentPoint(toEl, 'top', fromId, predecessorElements);
    } else { // transition-to-step
        const predecessorElements = diagram.transitions.filter(t => t.connectedTo.includes(toId)).map(t => t.id);
        p1 = getAttachmentPoint(fromEl, 'bottom', toId, fromEl.connectedTo);
        p2 = getAttachmentPoint(toEl, 'top', fromId, predecessorElements);
    }

    let { x: x1, y: y1 } = p1;
    let { x: x2, y: y2 } = p2;
    
    if (Math.abs(x1 - x2) < 1) { // Almost vertical line
      return `M ${x1} ${y1} V ${y2}`;
    } else {
      const midY = y1 + (y2 - y1) / 2;
      return `M ${x1} ${y1} V ${midY} H ${x2} V ${y2}`;
    }
}

function drawFrameAndTitleBlock(colors: any, projectInfo: any) {
    const { title, author, version } = projectInfo;
    const date = new Date().toLocaleDateString();
    
    return `
      <g id="frame-and-title-block">
        <!-- Page Border -->
        <rect x="0" y="0" width="${A4_WIDTH}" height="${A4_HEIGHT}" fill="${colors.bg}" />
        <rect x="${MARGIN}" y="${MARGIN}" width="${PRINTABLE_WIDTH}" height="${PRINTABLE_HEIGHT}" fill="none" stroke="${colors.fg}" stroke-width="2.5" />
        <rect x="${MARGIN - 5}" y="${MARGIN - 5}" width="${PRINTABLE_WIDTH + 10}" height="${PRINTABLE_HEIGHT + 10}" fill="none" stroke="${colors.fg}" stroke-width="1" />

        <!-- Title Block -->
        <g id="title-block" transform="translate(${MARGIN}, ${A4_HEIGHT - MARGIN - TITLE_BLOCK_HEIGHT})">
          <rect x="0" y="0" width="${PRINTABLE_WIDTH}" height="${TITLE_BLOCK_HEIGHT}" fill="none" stroke="${colors.fg}" stroke-width="1.5" />
          
          <!-- Sections -->
          <line x1="180" y1="0" x2="180" y2="${TITLE_BLOCK_HEIGHT}" stroke="${colors.fg}" stroke-width="1" />
          <line x1="520" y1="0" x2="520" y2="${TITLE_BLOCK_HEIGHT}" stroke="${colors.fg}" stroke-width="1" />
          
          <line x1="180" y1="30" x2="520" y2="30" stroke="${colors.fg}" stroke-width="1" />
          <line x1="180" y1="60" x2="520" y2="60" stroke="${colors.fg}" stroke-width="1" />

          <!-- Content -->
          <text x="10" y="18" font-family="Inter, sans-serif" font-size="11" fill="${colors.mutedFg}">Author:</text>
          <text x="10" y="35" font-family="Inter, sans-serif" font-size="14" fill="${colors.fg}" font-weight="500">${author}</text>
          
          <text x="10" y="58" font-family="Inter, sans-serif" font-size="11" fill="${colors.mutedFg}">Date:</text>
          <text x="10" y="75" font-family="Inter, sans-serif" font-size="14" fill="${colors.fg}" font-weight="500">${date}</text>
          
          <text x="190" y="18" font-family="Inter, sans-serif" font-size="11" fill="${colors.mutedFg}">Project Title:</text>
          <text x="190" y="48" font-family="Inter, sans-serif" font-size="20" fill="${colors.fg}" font-weight="600">${title}</text>
          
          <text x="530" y="18" font-family="Inter, sans-serif" font-size="11" fill="${colors.mutedFg}">Version:</text>
          <text x="530" y="35" font-family="Inter, sans-serif" font-size="14" fill="${colors.fg}" font-weight="500">${version}</text>
          
          <text x="530" y="58" font-family="Inter, sans-serif" font-size="11" fill="${colors.mutedFg}">Page:</text>
          <text x="530" y="75" font-family="Inter, sans-serif" font-size="14" fill="${colors.fg}" font-weight="500">1 / 1</text>
          
        </g>
      </g>
    `;
}

export function generateSvgString(diagram: GrafcetDiagram, isDarkMode: boolean): string {
  const { steps, transitions, references, projectInfo } = diagram;
  
  const allElements = [...steps, ...transitions, ...(references || [])];
  const hasContent = allElements.length > 0;

  let diagramMinX = 0, diagramMinY = 0, diagramMaxX = 200, diagramMaxY = 100;
  if (hasContent) {
      diagramMinX = Math.min(...allElements.map(el => el.position.x));
      diagramMinY = Math.min(...allElements.map(el => el.position.y));
      diagramMaxX = Math.max(...allElements.map(el => el.position.x + getElementDimensions(el).width + (el.actions?.length ? 150 : 0))); // Add space for actions text
      diagramMaxY = Math.max(...allElements.map(el => el.position.y + getElementDimensions(el).height));
  }
  
  const diagramWidth = diagramMaxX - diagramMinX;
  const diagramHeight = diagramMaxY - diagramMinY;

  // --- Scaling and Centering Logic ---
  const scaleX = diagramWidth > 0 ? PRINTABLE_WIDTH / diagramWidth : 1;
  const scaleY = diagramHeight > 0 ? DIAGRAM_AREA_HEIGHT / diagramHeight : 1;
  const scale = Math.min(scaleX, scaleY, 1); // Do not scale up, only down

  const scaledDiagramWidth = diagramWidth * scale;
  const scaledDiagramHeight = diagramHeight * scale;

  const translateX = MARGIN + (PRINTABLE_WIDTH - scaledDiagramWidth) / 2 - (diagramMinX * scale);
  const translateY = MARGIN + (DIAGRAM_AREA_HEIGHT - scaledDiagramHeight) / 2 - (diagramMinY * scale);

  const colors = {
    bg: isDarkMode ? '#09090b' : '#ffffff',
    fg: isDarkMode ? '#fafafa' : '#09090b',
    card: isDarkMode ? '#09090b' : '#ffffff',
    border: isDarkMode ? '#27272a' : '#e4e4e7',
    mutedFg: isDarkMode ? '#a1a1aa' : '#71717a',
  };

  const stepSvgs = steps.map(step => {
    const isAnd = step.type.startsWith('AND');
    const width = step.width || STEP_SIZE;
    const height = isAnd ? 12 : STEP_SIZE;

    if (isAnd) {
      return `
        <g transform="translate(${step.position.x}, ${step.position.y})">
            <line x1="0" y1="1" x2="${width}" y2="1" stroke="${colors.fg}" stroke-width="1.5" />
            <line x1="0" y1="11" x2="${width}" y2="11" stroke="${colors.fg}" stroke-width="1.5" />
        </g>
      `;
    }

    const actionsText = step.actions.filter(a => a.variable).map(a => `${a.variable} := ${a.logic}`).join(', ');

    return `
      <g transform="translate(${step.position.x}, ${step.position.y})">
        <rect x="0" y="0" width="${STEP_SIZE}" height="${STEP_SIZE}" fill="${colors.card}" stroke="${colors.fg}" stroke-width="1.5" />
        ${step.type === 'STEP_INITIAL' ? `<rect x="${INITIAL_STEP_INSET}" y="${INITIAL_STEP_INSET}" width="${STEP_SIZE - INITIAL_STEP_INSET * 2}" height="${STEP_SIZE - INITIAL_STEP_INSET * 2}" fill="none" stroke="${colors.fg}" stroke-width="1.5" />` : ''}
        <text x="${STEP_SIZE / 2}" y="${STEP_SIZE / 2}" font-family="Inter, sans-serif" font-size="16" font-weight="600" fill="${colors.fg}" text-anchor="middle" dominant-baseline="central">${step.label}</text>
        ${actionsText ? `<text x="${STEP_SIZE + 8}" y="${STEP_SIZE / 2}" font-family="monospace" font-size="12" fill="${colors.fg}" text-anchor="start" dominant-baseline="central">${actionsText}</text>` : ''}
      </g>
    `;
  }).join('');

  const transitionSvgs = transitions.map(trans => `
      <g transform="translate(${trans.position.x}, ${trans.position.y})">
        <line x1="0" y1="${TRANSITION_HEIGHT / 2}" x2="${TRANSITION_WIDTH}" y2="${TRANSITION_HEIGHT / 2}" stroke="${colors.fg}" stroke-width="1.5" />
        <line x1="${TRANSITION_WIDTH/2}" y1="0" x2="${TRANSITION_WIDTH/2}" y2="${TRANSITION_HEIGHT}" stroke="${colors.fg}" stroke-width="1.5" />
        <text x="${TRANSITION_WIDTH + 8}" y="${TRANSITION_HEIGHT / 2}" font-family="monospace" font-size="12" fill="${colors.fg}" text-anchor="start" dominant-baseline="central">${trans.condition}</text>
      </g>
    `).join('');

  const referenceSvgs = (references || []).map(ref => {
    let path, textY;
    if (ref.type === 'REFERENCE_OUT') {
        path = `<path d="M 0 0 L ${REFERENCE_WIDTH} 0 L ${REFERENCE_WIDTH/2} ${REFERENCE_HEIGHT} Z" fill="${colors.card}" stroke="${colors.fg}" stroke-width="1.5" />`;
        textY = REFERENCE_HEIGHT + 12;
    } else { // REFERENCE_IN
        path = `<path d="M 0 ${REFERENCE_HEIGHT} L ${REFERENCE_WIDTH} ${REFERENCE_HEIGHT} L ${REFERENCE_WIDTH/2} 0 Z" fill="${colors.card}" stroke="${colors.fg}" stroke-width="1.5" />`;
        textY = -8;
    }
    return `
        <g transform="translate(${ref.position.x}, ${ref.position.y})">
            ${path}
            <text x="${REFERENCE_WIDTH / 2}" y="${textY}" font-family="Inter, sans-serif" font-size="12" fill="${colors.fg}" text-anchor="middle">${ref.targetLabel}</text>
        </g>
    `;
  }).join('');
  
  const linkSvgs = hasContent ? `
    <defs>
      <marker id="arrowhead" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M 0 0 L 10 5 L 0 10 z" fill="${colors.fg}" />
      </marker>
    </defs>
    <g>
    ${[...(steps || []), ...(references || [])].flatMap(el =>
        el.connectedTo.map(targetId => (
          `<path d="${getLinkPath(diagram, el.id, targetId, 'step-to-transition')}" stroke="${colors.fg}" stroke-width="1.5" fill="none" marker-end="url(#arrowhead)" />`
        ))
      ).join('')}
    ${(transitions || []).flatMap(el =>
        el.connectedTo.map(targetId => (
            `<path d="${getLinkPath(diagram, el.id, targetId, 'transition-to-step')}" stroke="${colors.fg}" stroke-width="1.5" fill="none" marker-end="url(#arrowhead)" />`
        ))
      ).join('')}
    </g>
  ` : '';

  return `
    <svg width="${A4_WIDTH}" height="${A4_HEIGHT}" viewBox="0 0 ${A4_WIDTH} ${A4_HEIGHT}" xmlns="http://www.w3.org/2000/svg" style="background-color: ${colors.bg}; font-family: Inter, sans-serif;">
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&amp;family=Roboto+Mono&amp;display=swap');
      </style>
      
      ${drawFrameAndTitleBlock(colors, projectInfo)}
      
      <g id="diagram-content" transform="translate(${translateX}, ${translateY}) scale(${scale})">
        ${linkSvgs}
        ${stepSvgs}
        ${transitionSvgs}
        ${referenceSvgs}
      </g>
    </svg>
  `;
}
